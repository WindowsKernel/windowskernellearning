#include <ntifs.h>

#define _DEVICE_NAME L"\\device\\neihedaren"
#define _SYM_NAME L"\\??\\neihedaren"   //  \\\\.\\xxxxxx   \\dosDevice\\


NTSTATUS DefDispatch(
	_In_ struct _DEVICE_OBJECT *DeviceObject,
	_Inout_ struct _IRP *Irp
)
{

	DbgPrintEx(77, 0, "[db]:\r\n");
	IoCompleteRequest(Irp, 0);
	return STATUS_SUCCESS;
}


NTSTATUS Dispatch(
	_In_ struct _DEVICE_OBJECT *DeviceObject,
	_Inout_ struct _IRP *Irp
)
{
	DbgPrintEx(77, 0, "[db]:%s\r\n",__FUNCTION__);
	IoCompleteRequest(Irp, 0);
	return STATUS_SUCCESS;
}

VOID DriverUnload(PDRIVER_OBJECT pDriver)
{
	if (pDriver->DeviceObject)
	{
		UNICODE_STRING UnSymName = { 0 };
		RtlInitUnicodeString(&UnSymName, _SYM_NAME);
		IoDeleteSymbolicLink(&UnSymName);

		IoDeleteDevice(pDriver->DeviceObject);
	}
}

NTSTATUS DriverEntry(PDRIVER_OBJECT pDriver, PUNICODE_STRING pReg)
{

	UNICODE_STRING UnDeviceName = {0};
	RtlInitUnicodeString(&UnDeviceName, _DEVICE_NAME);

	UNICODE_STRING UnSymName = { 0 };
	RtlInitUnicodeString(&UnSymName, _SYM_NAME);
	DbgBreakPoint();
	//��һ�������豸����
	PDEVICE_OBJECT pDevice = NULL;
	NTSTATUS st = IoCreateDevice(pDriver, 0, &UnDeviceName, FILE_DEVICE_UNKNOWN, FILE_DEVICE_SECURE_OPEN, FALSE, &pDevice);

	if (!NT_SUCCESS(st))
	{
		return STATUS_UNSUCCESSFUL;
	}

	//�ڶ���������������
	st = IoCreateSymbolicLink(&UnSymName,&UnDeviceName);

	if (!NT_SUCCESS(st))
	{

		IoDeleteDevice(pDevice);
		return STATUS_UNSUCCESSFUL;
	}

	//�����������豸��־  ȥ����ʼ����
	pDevice->Flags &= ~DO_DEVICE_INITIALIZING;

	//���Ĳ� ʹ��ʲô�ڴ�
	pDevice->Flags |= DO_BUFFERED_IO;

	//
	pDriver->MajorFunction[IRP_MJ_CREATE] = DefDispatch;
	pDriver->MajorFunction[IRP_MJ_CLOSE] = DefDispatch;
	pDriver->MajorFunction[IRP_MJ_DEVICE_CONTROL] = Dispatch;
	//���岽���ûص�
	

	pDriver->DriverUnload = DriverUnload;
	return STATUS_SUCCESS;
}