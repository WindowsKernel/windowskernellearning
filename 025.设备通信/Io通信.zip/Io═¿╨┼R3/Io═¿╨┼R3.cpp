// Ioͨ��R3.cpp : �������̨Ӧ�ó������ڵ㡣
//

#include "stdafx.h"
#include <Windows.h>

#define _SYM_NAME "\\\\.\\neihedaren"   //  \\\\.\\xxxxxx   \\dosDevice\\

int main()
{

	HANDLE hDevice = CreateFileA(_SYM_NAME, GENERIC_READ | GENERIC_WRITE, FILE_SHARE_READ | FILE_SHARE_WRITE,NULL, OPEN_EXISTING, FILE_ATTRIBUTE_NORMAL,NULL);

	if (!hDevice)
	{
		printf("���豸ʧ��%d\r\n",GetLastError());
		
	}
	else 
	{
		system("pause");
		ULONG x = 0;
		ULONG retLen = 0;
		BOOL isSuccess = DeviceIoControl(hDevice, 0, &x, 4, &x, 4, &retLen, 0);

		printf("success %d,%d\r\n", isSuccess,GetLastError());

		system("pause");

		isSuccess = DeviceIoControl(hDevice, 0, &x, 4, &x, 4, &retLen, 0);

		printf("success %d,%d\r\n", isSuccess, GetLastError());

	}
	system("pause");
    return 0;
}

